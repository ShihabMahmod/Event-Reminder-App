<!DOCTYPE html>
<html>
<head>
    <title>Event Reminder</title>
</head>
<body>
    <h1>Event Reminder</h1>
    <p>Don't forget about the event: {{ $event->title }}.</p>
    <p>It starts at: {{ $event->start_time }}.</p>
</body>
</html>
