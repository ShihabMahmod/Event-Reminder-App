@extends('layout')
@section('content')
    <div class="container">
        <div class="mt-5 text-center">
            <img  style="height:200px;width:200px;" src="{{asset('icon-192x192.png')}}" alt="">
        </div>
        <h1 class="mt-5 text-center">Welcome to Event Reminder App</h1>
    </div>
@endsection