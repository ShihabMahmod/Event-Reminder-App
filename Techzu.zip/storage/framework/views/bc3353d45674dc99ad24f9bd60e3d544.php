<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="theme-color" content="#6777ef"/>
    <link rel="apple-touch-icon" href="<?php echo e(asset('techzu.png')); ?>">
    <link rel="manifest" href="<?php echo e(asset('/manifest.json')); ?>">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Upcoming Events</h1>
    <ul>
        <?php $__currentLoopData = $upcomingEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($event->title); ?> (<?php echo e($event->start_time); ?>) - 
                <a href="<?php echo e(route('event.edit', $event->id)); ?>">Edit</a>
                <form action="<?php echo e(route('event.destroy', $event->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit">Delete</button>
                </form>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <h1>Completed Events</h1>
    <ul>
        <?php $__currentLoopData = $completedEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($event->title); ?> (<?php echo e($event->start_time); ?>)</li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <a href="<?php echo e(route('event.create')); ?>">Create New Event</a>



    <script src="<?php echo e(asset('/sw.js')); ?>"></script>
    <script>
    if (!navigator.serviceWorker.controller) {
        navigator.serviceWorker.register("/sw.js").then(function (reg) {
            console.log("Service worker has been registered for scope: " + reg.scope);
        });
    }
    </script>
</body>
</html>
<?php /**PATH C:\Users\88018\Desktop\My Work-station\Laravel\Techzu\resources\views\events\index.blade.php ENDPATH**/ ?>