<h1>Create Event</h1>
<form action="<?php echo e(route('event.update',$event->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <label>Title</label>
    <input type="text" name="title" value="<?php echo e($event->title); ?>" required>

    <label>Ticket Price</label>
    <input type="number" name="ticket_price" value="<?php echo e($event->ticket_price); ?>" required>

    <label>Description</label>
    <textarea name="description"><?php echo e($event->description); ?></textarea>

    <label>Start Time</label>
    <input type="datetime-local" value="<?php echo e($event->start_time); ?>" name="start_time" required>

    <label>End Time</label>
    <input type="datetime-local" value="<?php echo e($event->end_time); ?>" name="end_time" required>

    <label>Reminder Time</label>
    <input type="datetime-local" value="<?php echo e($event->reminder_time); ?>" name="reminder_time" required>

    <button type="submit">Update</button>
</form>
<?php /**PATH C:\Users\88018\Desktop\My Work-station\Laravel\Techzu\resources\views\events\edit.blade.php ENDPATH**/ ?>